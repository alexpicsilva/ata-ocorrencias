       
    </div> <!-- CLOSE CONTAINER -->
      <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 bg-light border-top">
        <div class="col-md-4 d-flex align-items-center">
            <a class="navbar-brand mx-2" target="blanc" href="https://castsegjuizdefora.com.br/">
            <img src="img/castseg.png" alt="" height="35">
            </a>
          <span class="mb-3 mb-md-0 text-muted">© <?= date('Y')?> <!--Gabriel Quina--></span>
        </div>
        <!--<ul class="nav col-md-4 justify-content-end list-unstyled d-flex mx-2">
          <li class="ms-3"><a class="text-muted" href="#"><i class="bi bi-twitter" width="24" height="24"></i></a></li>
          <li class="ms-3"><a class="text-muted" href="#"><i class="bi bi-instagram" width="24" height="24"></i></a></li>
          <li class="ms-3"><a class="text-muted" href="#"><i class="bi bi-facebook" width="24" height="24"></i></a></li>
        </ul>-->
      </footer>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>